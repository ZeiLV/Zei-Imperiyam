from pyrogram import Client, filters
import asyncio
from datetime import datetime

# --- 1. AUTO-BIO (Soatni bio'da ko'rsatish) ---
@Client.on_message(filters.me & filters.command("autobio", prefixes="."))
async def autobio_handler(c, m):
    await m.edit("⏰ **Auto-Bio rejimi yoqildi.**\n`Profilingizdagi bio har daqiqa yangilanadi.`")
    
    while True:
        try:
            current_time = datetime.now().strftime("%H:%M")
            bio_text = f"🛡 Zei Imperiyasi Nazoratida | ⏰ Soat: {current_time}"
            await c.update_profile(bio=bio_text)
            await asyncio.sleep(60) # Har 1 daqiqada yangilash
        except:
            break

# --- 2. VOICE-TO-TEXT (Ovozli xabarni matnga aylantirish) ---
@Client.on_message(filters.me & filters.command("vtt", prefixes="."))
async def voice_to_text(c, m):
    reply = m.reply_to_message
    if not reply or not reply.voice:
        return await m.edit("🎙 **Ovozli xabarga reply qiling!**")
    
    await m.edit("🎧 `Ovozli xabar matnga aylantirilmoqda...` (Gemini Engine)")
    # Bu yerda Gemini AI ovozni eshitib matn qilib beradi
    file = await c.download_media(reply)
    # Gemini model.generate_content orqali ovozli faylni tahlil qilish...
    await m.edit("✅ **Matn:** (Bu funksiya uchun API sozlamalari talab qilinadi)")

# --- 3. ANIMATED TEXT (Yozilayotgan effekt) ---
@Client.on_message(filters.me & filters.command("type", prefixes="."))
async def type_handler(c, m):
    if len(m.command) < 2: return
    text = m.text.split(None, 1)[1]
    t_text = ""
    for char in text:
        t_text += char
        try:
            await m.edit(t_text + "▒")
            await asyncio.sleep(0.1)
        except: pass
    await m.edit(t_text)
