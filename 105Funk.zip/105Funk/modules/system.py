from pyrogram import Client, filters
import os, sys

@Client.on_message(filters.me & filters.command("ping", prefixes="."))
async def ping_handler(c, m):
    import time
    start = time.time()
    await m.edit("🏓 `Pong...`")
    end = time.time()
    await m.edit(f"🚀 **Zei Speed:** `{(end - start) * 1000:.2f} ms` \n🛰 **Server:** Pella Cloud")

@Client.on_message(filters.me & filters.command("restart", prefixes="."))
async def restart_bot(c, m):
    await m.edit("🔄 **Imperiya tizimi qayta yuklanmoqda...**")
    os.execl(sys.executable, sys.executable, *sys.argv)
