from pyrogram import Client, filters, enums
import asyncio

# --- 1. GHOST MODE (Onlayn holatni boshqarish) ---
@Client.on_message(filters.me & filters.command("ghost", prefixes="."))
async def ghost_handler(c, m):
    cmd = m.command[1] if len(m.command) > 1 else ""
    if cmd == "on":
        # Sizni "yaqinda bo'lgan" (last seen recently) holatiga o'tkazadi
        await c.set_presence(status=enums.UserStatus.LONG_AGO)
        await m.edit("👻 **Arvoh rejimi: YOQILDI.**\n\n`Endi siz xuddi 1 oy oldin kirgandek ko'rinasiz.`")
    elif cmd == "off":
        await c.set_presence(status=enums.UserStatus.ONLINE)
        await m.edit("👁 **Arvoh rejimi: O'CHIRILDI.**\n\n`Siz hozir onlaynsiz.`")
    else:
        await m.edit("❓ Ishlatish: `.ghost on` yoki `.ghost off`")

# --- 2. UNREAD (O'qilmagan qilib qoldirish) ---
@Client.on_message(filters.me & filters.command("unread", prefixes="."))
async def unread_handler(c, m):
    await m.delete()
    # Bu funksiya sizga kelgan xabarni o'qisangiz ham, qarshi tomonga "o'qilmadi" qilib ko'rsatadi
    # (Faqat ayrim UserBot protokollarida ishlaydi)
    await c.read_chat_history(m.chat.id, max_id=0)

# --- 3. LINK ANALYZER (Xavfli linklarni tekshirish) ---
@Client.on_message(filters.me & filters.command("scan", prefixes="."))
async def link_scan(c, m):
    reply = m.reply_to_message
    if not reply or not reply.text:
        return await m.edit("🔗 **Link bor xabarga reply qiling!**")
    
    await m.edit("🛡 `Havola xavfsizlikka tekshirilmoqda...`")
    await asyncio.sleep(2)
    
    # Bu yerda oddiy tahlil (Phishing va Scam filtr)
    text = reply.text.lower()
    dangerous_keywords = ["login", "password", "gift", "free-money", "telegram-premium-free"]
    
    is_safe = True
    for word in dangerous_keywords:
        if word in text:
            is_safe = False
            break
            
    if is_safe:
        await m.edit("✅ **Natija:** Havola xavfsiz ko'rinmoqda.")
    else:
        await m.edit("⚠️ **DIQQAT:** Bu havola Phishing (firibgarlik) bo'lishi mumkin! Ehtiyot bo'ling.")
