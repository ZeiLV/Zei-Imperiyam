from pyrogram import Client, filters
import asyncio

# --- 1. KO‘ZNI CHAQNATUVCHI (Rainbow Text) ---
@Client.on_message(filters.me & filters.command("rb", prefixes="."))
async def rainbow_handler(c, m):
    if len(m.command) < 2: return
    text = m.text.split(None, 1)[1]
    symbols = ["🔴", "🟠", "🟡", "🟢", "🔵", "🟣"]
    await m.edit("🌈")
    res = ""
    for char in text:
        res += char
        await m.edit(f"{symbols[len(res)%len(symbols)]} {res}")
        await asyncio.sleep(0.1)

# --- 2. ASABIY REJIM (Auto-Reply Troll) ---
asabiy_users = {}

@Client.on_message(filters.me & filters.command("asab", prefixes="."))
async def asab_toggle(c, m):
    reply = m.reply_to_message
    if not reply: return await m.edit("👤 **Kimni asabiylashtiramiz? (Reply qiling)**")
    user_id = reply.from_user.id
    if user_id in asabiy_users:
        del asabiy_users[user_id]
        await m.edit("✅ **Troll to'xtatildi.**")
    else:
        asabiy_users[user_id] = True
        await m.edit("😈 **Troll boshlandi! Endi u qochib qutula olmaydi.**")

@Client.on_message(filters.incoming & ~filters.me, group=2)
async def asab_watcher(c, m):
    if m.from_user and m.from_user.id in asabiy_users:
        texts = ["Sanga kim gapirdi? 🤫", "Juda aqllisanmi? 😂", "Vaqtimni olma!", "Zei Imperiyasi sani kuzatmoqda... 👁"]
        import random
        await m.reply_text(random.choice(texts))
