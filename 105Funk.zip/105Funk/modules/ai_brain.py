# modules/ai_brain.py
from pyrogram import Client, filters
import google.generativeai as genai
from config import GEMINI_KEY, PREFIX

genai.configure(api_key=GEMINI_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

@Client.on_message(filters.me & filters.command("ai", prefixes=PREFIX))
async def ai_handler(c, m):
    if len(m.command) < 2:
        return await m.edit("❓ Savol yozing...")
    
    query = m.text.split(None, 1)[1]
    await m.edit("🧠 `Zei AI o'ylamoqda...`")
    
    try:
        res = model.generate_content(query)
        await m.edit(f"🤖 **AI:**\n\n{res.text}")
    except Exception as e:
        await m.edit(f"❌ Xato: {e}")
