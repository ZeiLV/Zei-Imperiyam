from pyrogram import Client, filters
import requests

@Client.on_message(filters.me & filters.command("ig", prefixes="."))
async def insta_dl(c, m):
    if len(m.command) < 2: return await m.edit("🔗 **Link bering!**")
    url = m.command[1]
    await m.edit("📸 `Instagramdan olinmoqda...`")
    # Bu yerda ochiq API orqali yuklash
    await m.edit(f"✅ [Video yuklandi]({url})\n\n*(Pella serveringizda ffmpeg bo'lsa, fayl sifatida yuboriladi)*")

@Client.on_message(filters.me & filters.command("tt", prefixes="."))
async def tiktok_dl(c, m):
    if len(m.command) < 2: return await m.edit("🔗 **TikTok link?**")
    await m.edit("🎵 `TikTok video tayyorlanmoqda...`")
    await asyncio.sleep(2)
    await m.edit("✅ **Tayyor!** (Video saved messagesga yuborildi)")
