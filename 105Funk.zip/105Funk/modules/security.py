from pyrogram import Client, filters
from pyrogram.types import Message

# O'chirilgan xabarlarni saqlash uchun kesh (vaqtincha xotira)
msg_cache = {}

# Xabarlarni keshga yig'ib borish
@Client.on_message(filters.group | filters.private, group=-1)
async def cache_messages(c, m: Message):
    if m.text or m.caption:
        msg_cache[m.id] = {
            "text": m.text or m.caption,
            "user": m.from_user.first_name if m.from_user else "Noma'lum"
        }
    # Kesh juda kattalashib ketmasligi uchun (oxirgi 1000 ta xabar)
    if len(msg_cache) > 1000:
        msg_cache.pop(next(iter(msg_cache)))

# --- 1. ANTI-DELETE (Xabar o'chirilsa tutib olish) ---
@Client.on_deleted_messages()
async def anti_delete_handler(c, messages):
    for msg in messages:
        if msg.id in msg_cache:
            deleted = msg_cache[msg.id]
            # O'chirilgan xabarni faqat sizga (Saved Messages) yuboradi
            try:
                await c.send_message(
                    "me", 
                    f"🗑 **O'chirilgan xabar tutildi!**\n\n👤 **Kimdan:** {deleted['user']}\n💬 **Xabar:** `{deleted['text']}`"
                )
            except:
                pass

# --- 2. ANTI-EDIT (Tahrirlangan xabarni fosh qilish) ---
@Client.on_message_edit(filters.group | filters.private)
async def anti_edit_handler(c, m: Message):
    if m.id in msg_cache:
        old_text = msg_cache[m.id]['text']
        if old_text != (m.text or m.caption):
            await c.send_message(
                "me",
                f"📝 **Xabar tahrirlandi!**\n\n👤 **Kimdan:** {m.from_user.first_name}\n⬅️ **Eski holati:** `{old_text}`\n➡️ **Yangi holati:** `{m.text or m.caption}`"
            )
            # Keshni yangilab qo'yamiz
            msg_cache[m.id]['text'] = m.text or m.caption

# --- 3. SELF-DESTRUCT (O'zini o'zi yo'q qiladigan xabar) ---
@Client.on_message(filters.me & filters.command("sd", prefixes="."))
async def self_destruct(c, m: Message):
    if len(m.command) < 3:
        return await m.edit("❓ Ishlatish: `.sd [soniya] [matn]`")
    
    seconds = int(m.command[1])
    text = m.text.split(None, 2)[2]
    
    await m.edit(text)
    await asyncio.sleep(seconds)
    await m.delete()
