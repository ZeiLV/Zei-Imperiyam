from pyrogram import Client, filters
import asyncio

# --- 1. TAGALL (Guruhdagilarni bittada chaqirish) ---
@Client.on_message(filters.me & filters.command("tagall", prefixes="."))
async def tagall_handler(c, m):
    await m.delete()
    chat_id = m.chat.id
    string = ""
    count = 0
    
    async for member in c.get_chat_members(chat_id):
        if member.user.is_bot:
            continue
        string += f"[{member.user.first_name}](tg://user?id={member.user.id}) "
        count += 1
        # Har 5 ta odamni bitta xabarda chiqarish (Spam filtrga tushmaslik uchun)
        if count == 5:
            await c.send_message(chat_id, string)
            string = ""
            count = 0
            await asyncio.sleep(0.5)
    if string:
        await c.send_message(chat_id, string)

# --- 2. SPAM (Tezkor xabar yuborish) ---
@Client.on_message(filters.me & filters.command("spam", prefixes="."))
async def spam_handler(c, m):
    if len(m.command) < 3:
        return await m.edit("❓ **Xato!** Ishlatish: `.spam [soni] [matn]`")
    
    count = int(m.command[1])
    text = m.text.split(None, 2)[2]
    await m.delete()
    
    for _ in range(count):
        await c.send_message(m.chat.id, text)
        await asyncio.sleep(0.1) # Telegram bloklamasligi uchun kichik pauza

# --- 3. PURGE (Xabarlarni tozalash) ---
@Client.on_message(filters.me & filters.command("purge", prefixes="."))
async def purge_handler(c, m):
    if not m.reply_to_message:
        return await m.edit("❓ **Xabarga reply qiling!** Shu xabardan boshlab hammasini o'chiraman.")
    
    await m.edit("🧹 `Tozalanmoqda...`")
    msgs = []
    async for msg in c.get_chat_history(m.chat.id, offset_id=m.reply_to_message.id, reverse=True):
        msgs.append(msg.id)
        if len(msgs) == 100:
            await c.delete_messages(m.chat.id, msgs)
            msgs = []
    
    if msgs:
        await c.delete_messages(m.chat.id, msgs)
    await m.delete()
