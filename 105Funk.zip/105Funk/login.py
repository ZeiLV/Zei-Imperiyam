from pyrogram import Client

# Config.py dagi ma'lumotlaringni yoz
api_id = 34485894  # O'zingnikini qo'y
api_hash = "1dba043d8b17513e48eeb16a4a1dc90c" 

with Client("Zei_Empire", api_id=api_id, api_hash=api_hash) as app:
    print("\n✅ Sessiya muvaffaqiyatli yaratildi!")
    print("📂 Endi papkangizda 'Zei_Empire.session' fayli paydo bo'ldi.")
