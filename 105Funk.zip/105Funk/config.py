# config.py
API_ID = 34485894  # O'zingizniki
API_HASH = "1dba043d8b17513e48eeb16a4a1dc90c"
GEMINI_KEY = "AIzaSyCeoIKjqHRgNKGDSoBrKEsKB6AoiZmtwwQ"
PREFIX = "."  # Buyruqlar nuqta bilan boshlanadi
